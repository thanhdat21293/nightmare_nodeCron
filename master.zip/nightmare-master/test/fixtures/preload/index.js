window.__nightmare = {};
__nightmare.ipc = require('electron').ipcRenderer;
window.preload = 'custom'
